export default function ArticleOther() {
  return (
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias debitis
      repudiandae ullam accusamus ut alias impedit quidem commodi itaque facilis
      corrupti natus laboriosam ducimus, id numquam, quibusdam quod a ipsum?
    </p>
  );
}
