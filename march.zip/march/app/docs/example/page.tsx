export default function ArticleExample() {
  return (
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit magnam
      necessitatibus ipsum id totam sed, exercitationem sequi. Neque sequi
      voluptatum libero rem. Fuga beatae sed, consectetur perspiciatis est ad
      quaerat.
    </p>
  );
}
