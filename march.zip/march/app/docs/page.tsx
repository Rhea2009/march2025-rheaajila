export default function DocsPage() {
  return <div>Select An Article</div>;
}
