import { title } from "@/components/primitives";

export default function RecipePage() {
  return (
    <div>
      <h1 className={title()}>Recipe</h1>
      <div className="h-full w-full border-4 border-white flex flex-wrap justify-around p-6">
        <p> Easy recipe to create the Best Pancakes: </p>
      </div>
      <p>Ingredients: Eggs, Milk, Butter, Baking Soda, Salt, Sugar, Flour</p>
      <p>
        {" "}
        Step 3: Heat a non stick skillet - use medium heat if you have a strong
        stove, medium high if you have a weak one. Add a tiny bit of butter
        (about 1/2 tsp) and swirl to melt. Use paper towel to mostly wipe the
        butter off{" "}
      </p>
      <p>
        {" "}
        Step 4: Pour 1/4 cup batter into the middle of the fry pan (I use a
        slightly heaped ice cream scoop with lever, standard is 1/4 cup).{" "}
      </p>
      <p>
        {" "}
        Step 5: Swirl pan lightly to spread or use the ice cream scoop edge to
        spread into 11cm / 4.5&quot; circle{" "}
      </p>
      <p>
        {" "}
        Step 6: When bubbles rise to the surface, flip and cook the other side
        until golden.{" "}
      </p>
      <p> Step 7: Remove and keep warm in a low oven. </p>
      <p>
        {" "}
        Step 8: Use more butter every 2 to 3 pancakes - depends how good your
        non stick coating is{" "}
      </p>
      <p> And done!! Now you can enjoy!!</p>
      <img
        alt="Pancake"
        src="https://www.recipetineats.com/tachyon/2017/06/Pancakes-SQ.jpg?resize=900%2C900&zoom=0.72"
      />
      <div className="h-full w-full border-4 border-white flex flex-wrap justify-around p-4">
        <h1> Recipe for PB & J: </h1>
      </div>
      <p> Ingredients: Bread (of choice), Jam (of choice) and Peanut Butter</p>
      <p> Step 1: Get your bread, and toast/heat it to your desire</p>
      <p>
        {" "}
        Step 2: When bread is done heating, one half of your bread spread your
        Jam and the other half spread your Peanut Butter
      </p>
      <p> Step 3: Combine them and voila! A perfect PB&J</p>
      <img
        alt="PB AND J"
        src="https://tse4.mm.bing.net/th/id/OIP.JkxZm6tUrC8gRBqcnRfQTwHaE7?rs=1&pid=ImgDetMain"
      />
    </div>
  );
}
