"use client";
import { Button } from "@heroui/button";
import Image from "next/image";
import { useState } from "react";

import { title } from "@/components/primitives";

export default function AboutMePage() {
  let facts: string[] = [
    "A platypus is the only mammal that can lay eggs",
    "the average person blinks 14 times a minute",
    "Octopuses have 3 hearts",
    "Impossible fish",
    "Item6",
    "Item 7",
    "Item 8",
    "Item 9",
    "Item 10",
  ];
  const [fact, setFact] = useState("");

  return (
    <div>
      <h1 className={title()}>About Me</h1>
      <Button
        className="bg-green-800 text-white"
        onPress={() => {
          setFact(facts[Math.floor(Math.random() * facts.length)]);
        }}
      >
        Press 4 Fact
      </Button>
      <p>{fact}</p>
      <p>
        <p>tag with tag</p>
        elementception
      </p>
      <div className="flex gap-4 flex-wrap"> </div>
      <div className="h-full w-full border-4 border-white flex flex-wrap justify-around p-6">
        <p> My name is Rhea Ajila and this is my about me page!</p>
      </div>
      <div>
        <Image
          alt="playing soccer"
          height={400}
          src={"/meplayingsoccer.jpg"}
          width={400}
        />
        <p> This is me playing soccer!</p>
      </div>
      <a
        href="https://theecnl.com/sports/wsoc"
        rel="noreferrer"
        target="_blank"
      >
        ECNL GIRLS SOCCER CLICK HERE
      </a>
      {/* Sreevi: I don't think you need this canvas link anymore. */}
      <div className="h-full w-full border-4 border-white flex flex-wrap justify-around p-6">
        <b> Hobbies: </b>
      </div>
      <div className="h-full w-full flex gap-4 border border-white justify-around p-2">
        <img
          alt="Soccer Ball"
          height={400}
          src="https://tse3.mm.bing.net/th/id/OIP.ONUF2gIsOHqmILSozWH12AHaE8?rs=1&pid=ImgDetMain"
          width={400}
        />
      
      </div>
      <div>
        {" "}
        <p> -I play soccer</p>
        <p> -I love hanging out with my friends</p>
        <p> -going to the beach/lake</p>
      </div>
      {/*Sreevi: Maybe you could include your bulletpoints into your felxbox: just remove the div so that the text gets included into the flexbox.*/}
      <div className="h-full w-full border-4 border-white flex flex-wrap justify-around p-6">
        <b> Favorite Things:</b>
        {/* Is fav foods part of a list of ur favorite things? if so, maybe u could underline instead of making 2 seperate boxes (tiger) */}
      </div>
      <div />
      <div className="h-full w-full border-2 border-pink-400 flex flex-wrap justify-around p-2">
        <p> Favorite foods: Pasta, Crispy Garlic Chicken, strawberries </p>
        <img
          alt="Pasta"
          height={400}
          src="https://images.pexels.com/photos/1438672/pexels-photo-1438672.jpeg?cs=srgb&dl=pexels-enginakyurt-1438672.jpg&fm=jpg"
          width={400}
        />
      </div>
    </div>
  );
}
